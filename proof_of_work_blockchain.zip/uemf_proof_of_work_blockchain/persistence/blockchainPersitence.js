// const fs = require("fs")
// const { resolve } = require("path")
// const pathDb = "database/blockchain.json"
// const saveBlockchain = async (blockchain) => {
//     const { name, difficulty, miningInterval,
//         blockReward, denom, head } = blockchain

//     if (head != null) {
//         head = head.hash
//     }
//     try {
//         await fs.promises.writeFile(pathDb, JSON.stringify(
//             {
//                 name, difficulty, miningInterval, blockReward, denom, head
//             }, null, 3
//         ))
//         return true;
//     }
//     catch (e) {
//         console.error(e)
//         throw e
//     }
// }
// const loadBlockchain = () => {
//     return new Promise((resolve, reject) => {
//         fs.promises.readFile(pathDb)
//             .then(data => {
//                 data = JSON.parse(data)
//                 resolve(data)
//             })
//             .catch(e => {
//                 console.error(e)
//                 reject(null)
//             })
//     })
// }
// module.exports = {
//     loadBlockchain, saveBlockchain
// }

const fs = require("fs");
const path = require("path");

const pathDb = path.join(__dirname, "..", "database", "blockchain.json");

const Blockchain = require("../models/blockchain");
const Block = require("../models/block");

// Sauvegarde complète de la blockchain
const saveBlockchain = async (blockchain) => {
  await fs.promises.mkdir(path.dirname(pathDb), { recursive: true });
  await fs.promises.writeFile(pathDb, JSON.stringify(blockchain, null, 2));
  return true;
};

// Lecture + reconstruction d'une vraie instance de Blockchain
const loadBlockchain = async () => {
  const raw = await fs.promises.readFile(pathDb, "utf-8");
  const plain = JSON.parse(raw);

  const bc = new Blockchain(
    plain.name,
    plain.difficulty,
    plain.miningInterval,
    plain.blockReward,
    plain.denom
  );

  bc.chain = (plain.chain || []).map(b => Object.assign(new Block(), b));
  return bc;
};

module.exports = {
  loadBlockchain,
  saveBlockchain
};
