class Blockchain {
    constructor(name = "uemfBlockchain", difficulty = 6,
        miningInterval = 600, blockReward = 50, denom = "uemfCoin"
    ) {
        this.name = name
        this.difficulty = difficulty
        this.miningInterval = miningInterval
        this.blockReward = blockReward
        this.denom = denom
        this.head = null
        this.chain = [];
    }

    getBalances() {
        const balances = {};
        for (const block of this.chain) {
            for (const tx of block.transactions) {
                if (!balances[tx.fromAddress]) balances[tx.fromAddress] = 0;
                if (!balances[tx.toAddress]) balances[tx.toAddress] = 0;
                balances[tx.fromAddress] -= tx.amount;
                balances[tx.toAddress] += tx.amount;
            }
        }
        return balances;
    }
}

module.exports = Blockchain