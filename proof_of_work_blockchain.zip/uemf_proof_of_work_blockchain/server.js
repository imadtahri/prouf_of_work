const express = require('express');
const cors = require('cors');
const crypto = require('crypto');
const path = require('path');

const Blockchain = require('./models/blockchain');
const Block = require('./models/block');
const Transaction = require('./models/transaction');
const Wallet = require('./models/wallet');
const { saveBlockchain, loadBlockchain } = require('./persistence/blockchainPersitence');

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

let blockchain;
let mempool = [];

// Initialiser blockchain
async function initBlockchain() {
  try {
    blockchain = await loadBlockchain();
    console.log('Blockchain chargée depuis le disque.');
  } catch (e) {
    blockchain = new Blockchain("UEMF", 3, 600, 50, "uemfCoin");
    await saveBlockchain(blockchain);
    console.log('Nouvelle blockchain créée.');
  }
}

// GET /blocks
app.get('/blocks', (_, res) => {
  res.json(blockchain.chain);
});

// POST /transactions
app.post('/transactions', (req, res) => {
  const { fromAddress, toAddress, amount, signature } = req.body;
  if (!fromAddress || !toAddress || !amount) {
    return res.status(400).send("Champs manquants");
  }
  const tx = new Transaction(fromAddress, toAddress, amount, signature || '');
  mempool.push(tx);
  res.send('Transaction ajoutée au mempool');
});

// GET /mempool
app.get('/mempool', (_, res) => {
  res.json(mempool);
});

// POST /mine
app.post('/mine', async (_, res) => {
  if (mempool.length === 0) return res.send('Mempool vide');
  const lastBlock = blockchain.getLastBlock();
  const newBlock = new Block(
    blockchain.chain.length,
    new Date().toISOString(),
    [...mempool],
    lastBlock ? lastBlock.hash : '0'
  );
  blockchain.addBlock(newBlock);
  mempool = [];
  await saveBlockchain(blockchain);
  res.send('Bloc miné avec succès');
});

// GET /wallet
app.get('/wallet', (_, res) => {
  const wallet = new Wallet();
  res.json(wallet);
});

// GET /balances
app.get('/balances', (_, res) => {
  const balances = blockchain.getBalances();
  res.json(balances);
});

// POST /verify-transaction
app.post('/verify-transaction', (req, res) => {
  const { fromAddress, toAddress, amount, signature, publicKey } = req.body;
  if (!fromAddress || !toAddress || !amount || !signature || !publicKey) {
    return res.status(400).send("Champs manquants");
  }

  const verifier = crypto.createVerify('RSA-SHA256');
  verifier.update(fromAddress + toAddress + amount);
  const isValid = verifier.verify(publicKey, signature, 'base64');
  res.json({ valid: isValid });
});

// Lancer serveur
app.listen(PORT, async () => {
  await initBlockchain();
  console.log(`http://localhost:${PORT}`);
});
